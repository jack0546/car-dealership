document.addEventListener('DOMContentLoaded', () => {
    const studentListBody = document.getElementById('student-list-body');
    const searchInput = document.getElementById('student-search');
    const exportBtn = document.getElementById('export-csv');
    const presentCountEl = document.getElementById('present-count');
    const absentCountEl = document.getElementById('absent-count');
    const totalCountEl = document.getElementById('total-count');

    let students = [];
    const firstNames = ['James', 'Mary', 'Robert', 'Patricia', 'John', 'Jennifer', 'Michael', 'Linda', 'William', 'Elizabeth', 'David', 'Barbara', 'Richard', 'Susan', 'Joseph', 'Jessica', 'Thomas', 'Sarah', 'Charles', 'Karen'];
    const lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez', 'Hernandez', 'Lopez', 'Gonzales', 'Wilson', 'Anderson', 'Thomas', 'Taylor', 'Moore', 'Jackson', 'Martin'];

    // Generate 200 mock students
    function generateStudents() {
        for (let i = 1; i <= 200; i++) {
            const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
            const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
            students.push({
                id: `CS26-${i.toString().padStart(3, '0')}`,
                name: `${firstName} ${lastName}`,
                status: null // null, 'present', 'absent', 'late'
            });
        }
    }

    function renderStudents(filteredStudents = students) {
        studentListBody.innerHTML = '';
        filteredStudents.forEach(student => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td style="color: var(--text-muted); font-size: 0.8rem;">${student.id}</td>
                <td style="font-weight: 500;">${student.name}</td>
                <td>
                    <div class="attendance-actions">
                        <button class="status-btn present ${student.status === 'present' ? 'active' : ''}" data-id="${student.id}" data-status="present" title="Present">P</button>
                        <button class="status-btn absent ${student.status === 'absent' ? 'active' : ''}" data-id="${student.id}" data-status="absent" title="Absent">A</button>
                        <button class="status-btn late ${student.status === 'late' ? 'active' : ''}" data-id="${student.id}" data-status="late" title="Late">L</button>
                    </div>
                </td>
            `;
            studentListBody.appendChild(tr);
        });
        updateStats();
    }

    function updateStats() {
        const present = students.filter(s => s.status === 'present' || s.status === 'late').length;
        const absent = students.filter(s => s.status === 'absent').length;
        presentCountEl.textContent = present;
        absentCountEl.textContent = absent;
        totalCountEl.textContent = students.length;
    }

    // Handle attendance marking
    studentListBody.addEventListener('click', (e) => {
        const btn = e.target.closest('.status-btn');
        if (!btn) return;

        const id = btn.dataset.id;
        const status = btn.dataset.status;
        const student = students.find(s => s.id === id);

        if (student.status === status) {
            student.status = null;
        } else {
            student.status = status;
        }

        renderStudents(getFilteredStudents());
    });

    // Search functionality
    function getFilteredStudents() {
        const query = searchInput.value.toLowerCase();
        return students.filter(s => 
            s.name.toLowerCase().includes(query) || 
            s.id.toLowerCase().includes(query)
        );
    }

    searchInput.addEventListener('input', () => {
        renderStudents(getFilteredStudents());
    });

    // CSV Export
    exportBtn.addEventListener('click', () => {
        let csvContent = "data:text/csv;charset=utf-8,Student ID,Name,Status\n";
        students.forEach(s => {
            const statusStr = s.status ? s.status.charAt(0).toUpperCase() + s.status.slice(1) : 'Not Marked';
            csvContent += `${s.id},${s.name},${statusStr}\n`;
        });

        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "attendance_report.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    });

    // Initialize
    generateStudents();
    renderStudents();
});
